import keras
from keras_cv.models import EfficientNetV2Backbone
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image

# Load the model with the provided weights and specify the necessary parameters
model = EfficientNetV2Backbone(
    name="efficient_net_v2b0_backbone",
    weights="model.weights.h5",  # Path to the weights file
    trainable=False,  # Set False since we're not training it, just using for inference
    include_rescaling=True,
    width_coefficient=1.0,  # Width coefficient for scaling model's width
    depth_coefficient=1.0,  # Depth coefficient for scaling model's depth
    stackwise_kernel_sizes=[3, 3, 3, 3, 3, 3],  # Kernel sizes for each stack
    stackwise_num_repeats=[1, 2, 2, 3, 5, 8],  # Number of repeats for each stack
    stackwise_input_filters=[32, 16, 32, 48, 96, 112],  # Input filters for each stack
    stackwise_output_filters=[16, 32, 48, 96, 112, 192],  # Output filters for each stack
    stackwise_expansion_ratios=[1, 4, 4, 4, 6, 6],  # Expansion ratios for each stack
    stackwise_squeeze_and_excite_ratios=[0, 0, 0, 0.25, 0.25, 0.25],  # Squeeze & Excite ratios
    stackwise_strides=[1, 2, 2, 2, 1, 2],  # Strides for each stack
    stackwise_conv_types=["fused", "fused", "fused", "unfused", "unfused", "unfused"],  # Conv types for each stack
)

# Function to preprocess image for EfficientNetV2
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))  # Change size to match the input shape of EfficientNetV2
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
    img_array = img_array / 255.0  # Rescale image to [0, 1] range
    return img_array

# Example: Predict whether an image is real or fake
def predict_image(img_path):
    # Preprocess the image
    img_array = preprocess_image(img_path)
    
    # Run prediction
    prediction = model.predict(img_array)
    
    # Get the class with the highest probability
    predicted_class = np.argmax(prediction, axis=-1)
    
    # Create a dictionary for class mapping
    class_labels = {0: 'Real', 1: 'Fake'}
    
    # Get the label for the predicted class
    predicted_label = class_labels.get(predicted_class[0], 'Unknown')  # Default to 'Unknown' if class not in dict

    # Output the result
    print(f"Prediction: {predicted_label}")

# Example usage
img_path = "test.jpg"  # Replace with your image path
predict_image(img_path)
